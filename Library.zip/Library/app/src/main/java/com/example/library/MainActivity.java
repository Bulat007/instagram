package com.example.library;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.bumptech.glide.Glide;

import yanzhikai.textpath.TextPathView;

public class MainActivity extends AppCompatActivity {

    private View inflater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // TextPathView text  = findViewById(R.id.text);
        //text.startAnimation(0,1);
        ImageView img = findViewById(R.id.imageView1);
        Glide.with(this).load("http://goo.gl/gEgYUd").into(img);
}
    @Override
    public View getView(int position, View recycled, ViewGroup container){
        final ImageView myImageView;
        if (recycled == null){
            myImageView=(ImageView) inflater.inflate(R.layout.imageView1, container, false);
        }
        else {
            myImageView = (ImageView) recycled;
        }
    }
}
